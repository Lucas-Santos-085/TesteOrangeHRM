package suites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import testes.TesteInclusaoFuncionario;

@RunWith(Suite.class)
@SuiteClasses({

		TesteInclusaoFuncionario.class })

public class SuiteOrangeHRM {

}
